# -*- coding: utf-8 -*-

from flask import request, render_template, g
from flask import abort, redirect, url_for, flash
import shelve

from flasktodo import app
from flasktodo.models import Task


@app.before_request
def before_request():
    g.db = shelve.open(app.config['DATABASE'])
    if not 'tasks' in g.db:
        g.db['tasks'] = {}
    g.tasks = g.db['tasks']

@app.teardown_request
def teardown_request(exception):
    if hasattr(g, 'db'):
        if hasattr(g, 'tasks'):
            g.db['tasks'] = g.tasks
        g.db.close()

@app.route('/')
def tasks_list():
    tasks = g.tasks
    return render_template('tasks_list.html', tasks=tasks)

@app.route('/add/', methods=['GET', 'POST'])
def task_add():
    task = Task()
    error = None
    if request.method == 'POST':
        if 'description' in request.form and request.form['description']:
            # populate our task with data sent by the user
            task.description = request.form['description']

            # auto increment the key
            try:
                key = max(g.tasks.keys()) + 1
            except ValueError:
                key = 0

            # store our task in the tasks list
            g.tasks[key] = task

            flash('The task has been added.')

            # redirect the user to the tasks list
            return redirect(url_for('tasks_list'))
        else:
            # the user forgot to enter the task description
            error = 'You must enter something to do.'

    return render_template('task_add.html', task=task, error=error)

@app.route('/delete/<int:key>/')
def task_delete(key):
    if not key in g.tasks:
        abort(404)

    # remove the task from the list
    del g.tasks[key]

    flash('The task is removed.')

    # redirect the user to the tasks list
    return redirect(url_for('tasks_list'))

@app.route('/done/<int:key>/')
def task_done(key):
    if not key in g.tasks:
        abort(404)

    # mark the task as done
    g.tasks[key].done = True

    flash('The task is marked as done.')

    # redirect the user to the tasks list
    return redirect(url_for('tasks_list'))
