# -*- coding: utf-8 -*-

class Task():
    description = ""
    done = False
