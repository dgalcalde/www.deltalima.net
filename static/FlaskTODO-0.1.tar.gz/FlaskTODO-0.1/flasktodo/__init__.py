# -*- coding: utf-8 -*-

from flask import Flask

# Flask configuration
DEBUG = False
SECRET_KEY = 'you_should_change_this_key_asap'
DATABASE = '/tmp/flasktodo.db'

# Create our app
app = Flask(__name__)
app.config.from_object(__name__)

from flasktodo import views
